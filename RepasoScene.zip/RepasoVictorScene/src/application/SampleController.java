package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SampleController {
	@FXML
    private Button btnLogin;

    @FXML
    private TextField txtUsuario;

    @FXML
    private TextField txtPassword;
    
    @FXML
    public void login(ActionEvent event) {
    	//Creamos la alerta que aparecer� para decirnos si hemos introducido bien las credenciales
    	Alert alert = new Alert(AlertType.INFORMATION);
    	alert.setTitle("Informaci�n");
    	alert.setHeaderText(null);
    	
    	//Variables ficticias para emular un inicio de sesi�n
    	String usuario = "Pedro";
    	String password = "123456";
    	
    	//Comprobamos si coinciden los datos del login
    	if(txtUsuario.getText().equals(usuario) && txtPassword.getText().equals(password)) {
    		//Si coincide, nos muestra el siguiente mensaje
    		alert.setContentText("Ha iniciado sesi�n correctamente");
    		
    		try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("vistalogin.fxml"));
                Parent root1 = (Parent) fxmlLoader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root1));
                stage.show();
            } catch(Exception e) {
                e.printStackTrace();
            }
    		
    	}else {
    		//Si no hemos escrito bien nuestra credenciales, nos muestra este otro
    		alert.setContentText("Email y/o contrase�a incorrectos");
    		System.out.println(usuario +" "+password+" "+txtUsuario.getText()+" "+txtPassword.getText()+" ");
    	}
    	
    	alert.showAndWait();
    	
    	
    }

}
